website response check tool
===========================

Tool untuk mengecek respon/status website dev-mainpage.

Cara jalan:
  - Windows : jalankan langsung mainpage_check.exe
  - Linux   : wine mainpage_check.exe   (butuh wine 64-bit)

Tool menampilkan status respon server ("server alive").

Catatan:
  - mainpage_check.exe adalah biner Python (PyArmor + PyInstaller), khusus Windows x86_64.
  - Tool sudah di-obfuscate (PyArmor).
